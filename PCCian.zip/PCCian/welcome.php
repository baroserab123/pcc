
<?php
include('config.php');
$tbl_name="registered_members";
$myemail=$_POST['myemail'];
$mypassword=$_POST['mypassword'];
$myemail=stripslashes($myemail);
$mypassword=stripslashes($mypassword);
$myemail=mysql_real_escape_string($myemail);
$mypassword=mysql_real_escape_string($mypassword);


$sql=mysqli_query($link,"SELECT * FROM $tbl_name WHERE email='$myemail' and password='$mypassword'");


$count = mysqli_num_rows($sql);
if($count==1){
$_SESSION['myemail']="email";
$_SESSION['mypassword']="password";
header("location:welcomesuccess.php");
}

else
{
echo "Wrong username or password";
header("location:delete.html");
}
?>
