<?php
include ("config.php");

mysql_connect("$host","$username","$password")  or die ("cannot connect");
mysql_select_db("$db_name") or die("cannot select DB");

session_start();

$user_check=$_SESSION['login_user'];
$ses_sql=mysql_query("select username from $tbl_name where email='$user_check' ");
$$row=mysql_fetch_array($ses_sql);
$login_session=$row['email'];
if(!issest($login_session))
{
header("location:welcome2.php");
}
?>
