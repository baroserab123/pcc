<?php
//DATABASE CONNECTION VARIABLES
$host = "localhost"; // Host name
$username = ""; // Mysql username
$password = ""; // Mysql password
$db_name = "test"; // Database name



$link=mysqli_connect("$host", "$username", "$password") or die ("cannot connect");
mysqli_select_db($link,$db_name) or die ("cannot select DB");

?>