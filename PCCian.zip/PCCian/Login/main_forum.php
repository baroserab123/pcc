<!DOCTYPE html>
<html>
<head>
<title>PCCian</title>
<meta charset="utf-8">
<link rel="icon" href="pcc.jpg" type="image/x-icon" />
<link rel="shortcut icon" href="pcc.jpg" type="image/x-icon" />

<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="nw3.css">
 <link rel="stylesheet" href="font.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script src="google.js"></script>

</head>
<body>
<style>
body,h1, .td {font-family: "Montserrat", sans-serif; font-weight: bold}

</style>

<header>
  <div class="w3-container">
<div class="w3-container w3-padding-20 w3-center w3-opacity w3-margin">
 <span class="w3-opennav w3-xxlarge w3-right w3-margin-right" onclick="w3_open()"><i class="fa fa-bars"></i></span>
  <div class="w3-clear"></div>
  <h1>PCCian</h1>
  <p>Persons of Character and Competence</p>

</div></div>
</header>
<div class="w3-container">
 <!-- Sidenav/menu -->
 <div class="w3-quarter w3-container">

<nav class="w3-sidenav w3-collapse w3-white " style="z-index:3;width:200px;" id="mySidenav" ><br>
  <div class="w3-container">
    <a href="#" onclick="w3_close()" class="w3-hide-large w3-right w3-jumbo w3-padding" title="close menu">
      <i class="fa fa-close"></i>
    </a>
    <img src="r24.jpg" style="width:50%;" class="w3-round"><br><br>
    <h3 class="w3-padding-0"><b>PCCian</b></h3>

  </div>
  <a href="welcome.php" class="w3-padding">HOME</a>
  <a href="about.html" class="w3-padding">ABOUT</a>
  <a href="contact.html" class="w3-padding">CONTACT</a>
  <a href="main_forum.php" class="w3-padding w3-text-teal">FORUM</a>
  <a href="contact.html" class="w3-padding">SHOP</a>
  <a href="logout.php" class="w3-padding">LOGOUT</a>

    <div class="w3-section w3-padding-top w3-large">
    <a href="https://web.facebook.com/baroseann" class="w3-hover-white w3-hover-text-indigo w3-show-inline-block"><i class="fa fa-facebook-official"></i></a>
    <a href="https://twitter.com/RabBarose" class="w3-hover-white w3-hover-text-light-blue w3-show-inline-block"><i class="fa fa-twitter"></i></a>
	 <a href="https://www.instagram.com/roseannbanal" class="w3-hover-white w3-hover-text-light-blue w3-show-inline-block"><i class="fa fa-instagram"></i></a>
  </div>

</nav>
</div>
<!-- Overlay effect when opening sidenav on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
  <!-- !PAGE CONTENT! -->



<div class="w3-half  w3-container">
  <?php

  include ("conf.php");

  $tbl_name="forum_question"; //TBL name

  $sql=mysqli_query($link,"SELECT * FROM $tbl_name ORDER BY id DESC");

  ?>

  <table width="100%" border="0" align="center" cellpadding="7" cellspacing="10" bgcolor = "#cccccc">
  <tr>
  <td width="6%" align="center" bgcolor="#e6e6e6"> <strong> # </strong> </td>
  <td width="53%" align="center" bgcolor="#e6e6e6"> <strong> Topic </strong> </td>
  <td width="15%" align="center" bgcolor="#e6e6e6"> <strong> Views </strong> </td>
  <td width="13%" align="center" bgcolor="#e6e6e6"> <strong> Replies </strong> </td>
  <td width="13%" align="center" bgcolor="#e6e6e6"> <strong> Date/Time </strong> </td>
  </tr>

  <?php
  while($rows=mysqli_fetch_array($sql)){
  ?>
  <tr>
    <td bgcolor="#ffffff"> <?php echo $rows['id'];?></td>
    <td bgcolor ="#ffffff"><a href="topic.php?id=<?php echo $rows['id'];?>"><?php echo $rows['topic'];?></a><br></td>

  <td bgcolor ="#ffffff"> <?php echo $rows['view']; ?></td>
  <td bgcolor ="#ffffff"> <?php echo $rows['reply']; ?></td>
  <td bgcolor ="#ffffff"> <?php echo $rows['datetime']; ?></td>
  <td><a href="deleteforum.php?id=<?php echo $rows['id'];?>">Delete</a></td>
  </tr>

  <?php
  }
  mysqli_close($link);
  ?>

  
  </table>
  <br>
  <br>
<center><p><a class="w3-btn  w3-hover-white" href='create_topic.php' style="background-color:crimson; width:200px"> Create New Topic</a></p></center>
  

</div>


	<br><br><br><br><br><br>




	<div class="w3-quarter w3-container">

</div>



      <div class="modal-footer">

      </div>
    </div>

  </div>
</div>
</div>


</div>

<!-- Footer -->


<div class="w3-container">
<footer class=" w3-padding-24 w3-light-grey w3-center w3-margin-top w3-opacity">
 <div class="w3-xlarge w3-padding-16">
 <p>PASIG CATHOLIC COLLEGE</p>
 <p>Malinao, Pasig City</p>
   <a href="#" class="w3-hover-text-indigo"><i class="fa fa-facebook-official"></i></a>

   <a href="#" class="w3-hover-text-light-blue"><i class="fa fa-twitter"></i></a>

 </div>

</footer>
</div>
  <script>
// Script to open and close sidenav
function w3_open() {
    document.getElementById("mySidenav").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
