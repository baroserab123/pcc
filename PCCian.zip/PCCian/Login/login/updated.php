<html>
<head style="background:red;margin-left:100px;margin-right:100px;">
<link rel="stylesheet" href="nw3.css">
</head>
<body>

<?php

include ("conf.php");

$tbl_name="members"; //TBL name


$username= $_POST['username'];

$email= $_POST['email'];


$id= $_POST['id'];

$sql=mysqli_query($link,"UPDATE $tbl_name SET username='$username',email='$email' WHERE id='$id'  ");



if($sql){
echo "<center>Successful";
echo "<br>";
echo "<center><a class='w3-btn  w3-hover-white' href='confirm.php' style='background-color:crimson; width:200px'>Display Records</a>";
}
else {
echo "ERROR";}

?>
<?php mysqli_close($link);
?>



</body>

</html>