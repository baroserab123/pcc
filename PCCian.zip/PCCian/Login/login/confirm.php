<html>
<head style="background:red;margin-left:100px;margin-right:100px;">
<link rel="stylesheet" href="nw3.css">
<link rel="stylesheet" href="arc.css">
<link rel="stylesheet" href="rale.css">
<style>
.w3-architect {
    font-family: "Architects Daughter", Sans-serif;
}
</style>
<style>
.body1 {font-family: Tempus Sans ITC;font-size:20px;}
</style>
<style>
h1,h3 {font-family: "Montserrat", sans-serif; font-weight: bold}


</style>

</head>

<div class="w3-container">
<div class="w3-container w3-padding-24 w3-center w3-opacity w3-margin-bottom">

  <h1>PCCian</h1>
  <h3>List of Registered Members</h3>

</div></div>






<body style="background:white;margin-left:100px;margin-right:100px">

<div class="w3-container w3-light-grey w3-card-12 w3-margin body2">
<div class="w3-section">
<?php

include ("conf.php");

$tbl_name="members"; //TBL name


$sql=mysqli_query($link,"SELECT * FROM $tbl_name");
?>
<center>
<br>
<br>
<table width= "500" border="0" cellspacing="3" cellpadding="4" >
<tr>
<td>
<table width= "500" border="1" cellspacing="0" cellpadding="7" >


<tr>
<td align="center"><strong> Student-ID</strong></td>
<td align="center"><strong> Username</strong></td>

<td align="center"><strong> Email</strong></td>


<td align="center"><strong> Update</strong></td>
<td align="center"><strong> Delete</strong></td>


</tr>

<?php
while($rows=mysqli_fetch_array($sql)){
?>

<tr>
<td><?php echo $rows['id'];?></td>
<td><?php echo $rows['username'];?></td>
<td><?php echo $rows['email'];?></td>


<td><a href="update.php?id=<?php echo $rows['id'];?>">Update</a></td>
<td><a href="delete.php?id=<?php echo $rows['id'];?>">Delete</a></td>
</tr>





<?php
}
?>
</table>
</td>
</tr>
</table>
<?php mysqli_close($link);
?>



</body>

</html>
