<html>
<head> 
<link rel="stylesheet" href="nw3.css">
<link rel="stylesheet" href="arc.css">
<link rel="stylesheet" href="rale.css">
<style>
.w3-architect {
    font-family: "Architects Daughter", Sans-serif;
}
</style>
<style>
.body1 {font-family: Tempus Sans ITC;font-size:20px;}
</style>
</head>
<link rel="stylesheet" href="nw3.css">


<style>
h1,h3 {font-family: "Montserrat", sans-serif; font-weight: bold}


</style>

<div class="w3-container">
<div class="w3-container w3-padding-24 w3-center w3-opacity w3-margin-bottom">

  <h1>PCCian</h1>
  <h3>Update Information of Registered Members</h3>
 
</div></div>
<body style="background:white;margin-left:100px;margin-right:100px">

<div class="w3-container w3-light-grey w3-card-12 w3-margin body2">
<div class="w3-section">

<?php

include ("conf.php");
$tbl_name="members"; //TBL name
$id=$_GET['id'];
$sql=mysqli_query($link,"SELECT * FROM $tbl_name WHERE id='$id'");
$rows=mysqli_fetch_array($sql);
?>
<center>
<table width= "500" border="0" cellspacing="1" cellpadding="0">
<tr>
<form name="form1" method ="post"
action="updated.php">
<td>
<table width= "500" border="1" cellspacing="0" cellpadding="3">
<tr>
<td colspan="8"><strong> Update Record</strong></td>
</tr>

<tr>
<td align="center"><strong> Student-ID</strong></td>
<td align="center"><strong> Username</strong></td>
<td align="center"><strong> Email</strong></td>


<td align="center"><strong> Update</strong></td>
</tr>
<tr>

<td align="center"><input name="id" type="hidden" id ="id"
value="<?php echo $rows['id'];?>"></td> 

<td align="center"><input name="username" type="text" id ="username"
value="<?php echo $rows['username'];?>"></td>


<td align="center"><input name="email" type="text" id ="email"
value="<?php echo $rows['email'];?>"></td>

	  




<td align="center"><input type="submit"
name="Submit" value="Submit"></td>

</tr>


</table>
</td>
</form>
</tr>
</table>
<?mysql_close();
?>




</body>

</html>
