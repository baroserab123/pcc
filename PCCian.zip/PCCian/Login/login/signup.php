<?php

?>

<!DOCTYPE html>
<html>
<head>
<title>PCCian</title>
<meta charset="utf-8">
<link rel="icon" href="pcc.jpg" type="image/x-icon" />
<link rel="shortcut icon" href="pcc.jpg" type="image/x-icon" />

<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="nw3.css">
 <link rel="stylesheet" href="font.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script src="google.js"></script>

</head>
<body>
<style>
body,h1 {font-family: "Montserrat", sans-serif; font-weight: bold}

</style>
<header>
  <div class="w3-container">
<div class="w3-container w3-padding-24 w3-center w3-opacity w3-margin-bottom">
 <span class="w3-opennav w3-xxlarge w3-right w3-margin-right" onclick="w3_open()"><i class="fa fa-bars"></i></span>
  <div class="w3-clear"></div>
  <h1>PCCian</h1>
  <p>Persons of Character and Competence</p>

</div></div>
</header>
<div class="w3-container">
 <!-- Sidenav/menu -->
 <div class="w3-quarter w3-container">

<nav class="w3-sidenav w3-collapse w3-white " style="z-index:3;width:200px;" id="mySidenav" ><br>
  <div class="w3-container">
    <a href="#" onclick="w3_close()" class="w3-hide-large w3-right w3-jumbo w3-padding" title="close menu">
      <i class="fa fa-close"></i>
    </a>
    <img src="r24.jpg" style="width:60%;" class="w3-round"><br><br>
    <h3 class="w3-padding-0"><b>PCCian</b></h3>

  </div>
  
  <a href="confirm.php" class="w3-padding">MANAGE ACCOUNTS</a>
  

    <div class="w3-section w3-padding-top w3-large">
    <a href="https://web.facebook.com/baroseann" class="w3-hover-white w3-hover-text-indigo w3-show-inline-block"><i class="fa fa-facebook-official"></i></a>
    <a href="https://twitter.com/RabBarose" class="w3-hover-white w3-hover-text-light-blue w3-show-inline-block"><i class="fa fa-twitter"></i></a>
	 <a href="https://www.instagram.com/roseannbanal" class="w3-hover-white w3-hover-text-light-blue w3-show-inline-block"><i class="fa fa-instagram"></i></a>
  </div>

</nav>
</div>
<!-- Overlay effect when opening sidenav on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
  <!-- !PAGE CONTENT! -->



<div class="w3-half  w3-container">
 <p></p>
 <div class="w3-half w3-padding">
   <img src="r46.jpg" style="width:100%;" class="w3-round"><br><br>
   <img src="r17.jpg" style="width:100%;" class="w3-round"><br><br>
     <img src="r51.jpg" style="width:100%;" class="w3-round"><br>
	   <img src="r52.jpg" style="width:100%;" class="w3-round"><br><br>
	   <img src="r48.jpg" style="width:100%;" class="w3-round"><br><br>
   </div>
   <div class="w3-half w3-padding">
   <img src="r50.jpg" style="width:100%;" class="w3-round"><br><br>
     <img src="r36.jpg" style="width:100%;" class="w3-round"><br><br>
	   <img src="r.jpg" style="width:100%;" class="w3-round"><br><br>
	     <img src="r15.jpg" style="width:100%;" class="w3-round"><br><br>
		 <img src="r12.jpg" style="width:100%;" class="w3-round"><br><br>
</div>
</div>


	<br><br><br><br><br><br>




	<div class="w3-quarter w3-container">
 <div class="w3-container w3-padding w3-border">
 <br>
<p style="font-family:Trirong; font-size:20px"> Already have an account?</p>
<br><br>
  

    <div class="form-group">
      <div class="">

<center><a href="main_login.php"   class="btn btn-info" role="button" style="background-color:crimson; width:180px">Log in</a></center>

      </div>
    </div>
  </form>
<br><br>


<p style="font-family:Trirong; font-size:20px">Starting a new application?</p>
<p>If you are new to our application please click the button below.</p>
 <div >
 <br><br>
 <center><a href="#myModal" data-toggle="modal" data-target="#myModal"  class="btn btn-info" role="button" style="background-color:crimson; width:180px">Create an account</a></center>

		<br>
		<br>
      </div>

 </div>
</div>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">

<div class="vertical-alignment-helper">
  <div class="modal-dialog vertical-align-center">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h2 class="modal-title">Register</h2>
      </div>

      <div class="modal-body">
	 

        <div class="tab-content">
        <div class="tab-pane active" id="tab1">
	       
		   
		   
            

      <form class="form-signup" id="usersignup" name="usersignup" method="post" action="createuser.php">
        <h2 class="form-signup-heading"></h2>
        <input name="newuser" id="newuser" type="text" class="form-control" placeholder="Username" autofocus>
		<br>
        <input name="email" id="email" type="text" class="form-control" placeholder="Email">
<br>
        <input name="password1" id="password1" type="password" class="form-control" placeholder="Password">
		<br>
        <input name="password2" id="password2" type="password" class="form-control" placeholder="Repeat Password">
		<br>
		<br>

        <button name="Submit" id="submit" class="btn btn-lg btn-primary btn-block" type="submit">Sign up</button>

        <div id="message"></div>
      </form>

    


		   </form>
       


        </div>
        </div>

      </div>
      <div class="modal-footer">

      </div>
    </div>

  </div>
</div>
</div>


</div>

<!-- Footer -->


<div class="w3-container">
<footer class=" w3-padding-24 w3-light-grey w3-center w3-margin-top w3-opacity">
 <div class="w3-xlarge w3-padding-16">
 <p>PASIG CATHOLIC COLLEGE</p>
 <p>Malinao, Pasig City</p>
   <a href="#" class="w3-hover-text-indigo"><i class="fa fa-facebook-official"></i></a>

   <a href="#" class="w3-hover-text-light-blue"><i class="fa fa-twitter"></i></a>

 </div>

</footer>
</div>
  <script>
// Script to open and close sidenav
function w3_open() {
    document.getElementById("mySidenav").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
 <!-- /container -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="//code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script type="text/javascript" src="js/bootstrap.js"></script>

    <script src="js/signup.js"></script>


    <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script>

$( "#usersignup" ).validate({
  rules: {
	email: {
		email: true,
		required: true
	},
    password1: {
      required: true,
      minlength: 4
	},
    password2: {
      equalTo: "#password1"
    }
  }
});
</script>

  </body>
</html>
