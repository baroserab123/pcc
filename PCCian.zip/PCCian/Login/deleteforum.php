<html>
<head>
<link rel="stylesheet" href="nw3.css">
</head>

<body>

<?php

include ("conf.php");

$tbl_name="forum_question"; //TBL name
$id= $_GET['id'];

$sql=mysqli_query($link,"DELETE FROM $tbl_name WHERE id='$id'");


if($sql){
echo "<center>Successful";
echo "<br>";
echo "<center><a class='w3-btn  w3-hover-white' href='main_forum.php' style='background-color:crimson; width:200px'>Display Records</a>";
}
else {
echo "ERROR";}



?>
<?php mysqli_close($link);
?>



</body>

</html>