<?php
include('conf.php');
if (isset($_POST['submit'])){
if(isset($_GET['go'])){
if(preg_match("/^[a-zA-Z]+/",$_POST['username'])){
$username=$_POST['username'];
$sql=mysqli_query($link,"SELECT id, username FROM members WHERE username LIKE '%" .$username. "%'");
while($row=mysqli_fetch_array($sql)){
$username = $row['username'];
$id=$row['id'];
echo "<ul>\n";
echo "<li>" . "<a href=\search.php?id=$id\">" .$username. "</a> </li>\n";
echo "</ul>";
}} else {echo "<p> Please enter search query</p>";
}}}
?>


<td><a href="update.php?id=<?php echo $rows['id'];?>">Update</a></td>