<?php
session_start();

if (!isset ($SESSION['myemail']))
{
header("location:welcome.html");
}
