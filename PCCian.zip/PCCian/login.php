<html>
<head>
<link rel="stylesheet" href="nw3.css">
</head>
<body>

<?php

include ("config.php");

$tbl_name="registered_members"; //TBL name


$lastname= $_POST['lastname'];
$firstname= $_POST['firstname'];
$email= $_POST['email'];
$password= $_POST['password'];
$country= $_POST['country'];


$sql=mysqli_query($link, "INSERT INTO $tbl_name(lastname, firstname, email, password, country) VALUES (  '$lastname', '$firstname','$email', '$password', '$country')");



if($sql){
echo "<center>Successful";
echo "<br>";
echo "<center><a class='w3-btn  w3-hover-white' href='confirm.php' style='background-color:crimson; width:200px'>Display Records</a>";
}
else {
echo "ERROR";}


?>




</body>

</html>
