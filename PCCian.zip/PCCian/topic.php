<!DOCTYPE html>
<html>
<head>
<title>PCCian</title>
<meta charset="utf-8">
<link rel="icon" href="pcc.jpg" type="image/x-icon" />
<link rel="shortcut icon" href="pcc.jpg" type="image/x-icon" />

<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="nw3.css">
 <link rel="stylesheet" href="font.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script src="google.js"></script>

</head>
<body>
<style>
body,h1 {font-family: "Montserrat", sans-serif; font-weight: bold}

</style>
<header>
  <div class="w3-container">
<div class="w3-container w3-padding-24 w3-center w3-opacity w3-margin-bottom">
 <span class="w3-opennav w3-xxlarge w3-right w3-margin-right" onclick="w3_open()"><i class="fa fa-bars"></i></span>
  <div class="w3-clear"></div>
  <h1>PCCian</h1>
  <p>Persons of Character and Competence</p>

</div></div>
</header>
<div class="w3-container">
 <!-- Sidenav/menu -->
 <div class="w3-quarter w3-container">

<nav class="w3-sidenav w3-collapse w3-white " style="z-index:3;width:300px;" id="mySidenav" ><br>
  <div class="w3-container">
    <a href="#" onclick="w3_close()" class="w3-hide-large w3-right w3-jumbo w3-padding" title="close menu">
      <i class="fa fa-close"></i>
    </a>
    <img src="r24.jpg" style="width:60%;" class="w3-round"><br><br>
    <h3 class="w3-padding-0"><b>PCCian</b></h3>

  </div>
  <a href="home.html" class="w3-padding w3-text-teal">HOME</a>
  <a href="about.html" class="w3-padding">ABOUT</a>
  <a href="contact.html" class="w3-padding">CONTACT</a>

    <div class="w3-section w3-padding-top w3-large">
    <a href="https://web.facebook.com/baroseann" class="w3-hover-white w3-hover-text-indigo w3-show-inline-block"><i class="fa fa-facebook-official"></i></a>
    <a href="https://twitter.com/RabBarose" class="w3-hover-white w3-hover-text-light-blue w3-show-inline-block"><i class="fa fa-twitter"></i></a>
	 <a href="https://www.instagram.com/roseannbanal" class="w3-hover-white w3-hover-text-light-blue w3-show-inline-block"><i class="fa fa-instagram"></i></a>
  </div>

</nav>
</div>
<!-- Overlay effect when opening sidenav on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
  <!-- !PAGE CONTENT! -->



<div class="w3-half  w3-container">
  <?php
  include ("config.php");

  $tbl_name="forum_question";

  $id =$_GET['id'];
  $sql=mysqli_query($link,"SELECT * FROM $tbl_name WHERE id='$id'");

  $rows=mysqli_fetch_array($sql);
   ?>

   <table width="400" border="0" align="center" cellpadding="1" bgcolor="#cccccc">
     <tr>
       <td><table width="100%" border="0" cellpadding="3" cellspacing="1" bordercolor ="1" bgcolor="#ffffff">
         <tr>
           <td bgcolor="#f8f7f1"><strong><?php echo  $rows['topic']; ?> </strong> </td>
         </tr>
         <tr>
           <td bgcolor="#f8f7f1"><?php echo  $rows['detail']; ?>  </td>
         </tr>
         <tr>
           <td bgcolor="#f8f7f1"><strong>By: </strong><?php echo  $rows['name']; ?> <strong> Email: </strong><?echo $rows['email'];?></td>
         </tr>
         <tr>
           <td bgcolor="#f8f7f1"><strong>Date/time: </strong><?php echo  $rows['datetime']; ?>  </td>
         </tr>
       </table></td>
     </tr>
   </table>
   <br>

   <?php
   $tbl_name2="forum_answer";


   $sql2=mysqli_query($link, "SELECT * FROM $tbl_name2 WHERE question_id='$id'");

   while ($rows=mysqli_fetch_array($sql2)){
     ?>


    <table width="400" border="0" align="center" cellpadding="1" bgcolor="#cccccc">
      <tr>
        <td><table width="100%" border="0" cellpadding="3" cellspacing="1" bordercolor ="1" bgcolor="#ffffff">
          <tr>
            <td bgcolor="#f8f7f1"><strong>ID</strong> </td>
            <td bgcolor="#f8f7f1">: </td>
            <td bgcolor="#f8f7f1"><?php echo $rows['a_id'];?> </td>
          </tr>
          <tr>
            <td width="18%" bgcolor="#f8f7f1"><strong>Name</strong> </td>
            <td width="5%" bgcolor="#f8f7f1">: </td>
            <td width="77%" bgcolor="#f8f7f1"><?php echo $rows['a_name'];?> </td>
          </tr>
          <tr>
            <td bgcolor="#f8f7f1"><strong>Email</strong> </td>
            <td bgcolor="#f8f7f1">: </td>
            <td bgcolor="#f8f7f1"><?php echo $rows['a_email'];?> </td>
          </tr>
          <tr>
            <td bgcolor="#f8f7f1"><strong>Answer</strong> </td>
            <td bgcolor="#f8f7f1">: </td>
            <td bgcolor="#f8f7f1"><?php echo $rows['a_answer'];?> </td>
          </tr>
          <tr>
            <td bgcolor="#f8f7f1"><strong>Date/Time</strong> </td>
            <td bgcolor="#f8f7f1">: </td>
            <td bgcolor="#f8f7f1"><?php echo $rows['a_datetime'];?> </td>
          </tr>
        </table></td>
      </tr>
    </table><br>

  <?php }

  $sql3=mysqli_query($link,"SELECT * FROM $tbl_name WHERE id='$id'");

  $rows=mysqli_fetch_array($sql3);
  $view=$rows['view'];


  if(empty($view)){
    $view=1;
    $sql4=mysqli_query($link,"INSERT INTO $tbl_name(view) VALUES ('$view') WHERE id='$id'");


  }

  $addview=$view+1;
  $sql5=mysqli_query($link,"update $tbl_name set view ='$addview' WHERE id='$id'");

  mysqli_close($link);
  ?>

  <br>

  <table width="400" border="0" align="center" cellpadding="1" bgcolor="#cccccc">
    <tr>
      <form name ="form1" method="post" action="add_answer.php">
      <td><table width="100%" border="0" cellpadding="3" cellspacing="1" bordercolor ="1" bgcolor="#ffffff">

        <tr>
          <td width="18%"><strong>Name</strong> </td>
          <td width="3%" >: </td>
          <td width="79%" ><input name="a_name" type="text" id="a_name" size ="45"></td>
        </tr>
        <tr>
          <td><strong>Email</strong> </td>
          <td  >: </td>
          <td  ><input name="a_email" type="text" id="a_email" size ="45"></td>
        </tr>
        <tr>
          <td valign="top"><strong>Answer</strong> </td>
          <td valign="top" >: </td>
          <td  ><textarea name="a_answer" cols="45" rows="3" id="a_answer"> </textarea></td>
        </tr>
        <td>&nbsp;</td>
        <td> <input name="id" type="hidden" value="<?php echo $id; ?>"> </td>
        <td> <input type="submit" name="Submit" value="Submit" /> <input type="reset" name="Submit2" value="Reset" /> </td>
      </tr>
    </table>
  </td>
  </form>
  </tr>
  </table>



</div>


	<br><br><br><br><br><br>




	<div class="w3-quarter w3-container">

</div>



      <div class="modal-footer">

      </div>
    </div>

  </div>
</div>
</div>


</div>

<!-- Footer -->


<div class="w3-container">
<footer class=" w3-padding-24 w3-light-grey w3-center w3-margin-top w3-opacity">
 <div class="w3-xlarge w3-padding-16">
 <p>PASIG CATHOLIC COLLEGE</p>
 <p>Malinao, Pasig City</p>
   <a href="#" class="w3-hover-text-indigo"><i class="fa fa-facebook-official"></i></a>

   <a href="#" class="w3-hover-text-light-blue"><i class="fa fa-twitter"></i></a>

 </div>

</footer>
</div>
  <script>
// Script to open and close sidenav
function w3_open() {
    document.getElementById("mySidenav").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
