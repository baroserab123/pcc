<?php
session_start();
include ("config.php");
$tbl_name="pccian"; //TBL name
// Connect to server and select DB
mysql_connect("$host","$username","$password")  or die ("cannot connect");
mysql_select_db("$db_name") or die("cannot select DB");

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
$myemail=addslashes($_POST['email']);
$mypassword=addslashes($_POST['password']);

$sql="SELECT * FROM $tbl_name WHERE email='$myemail' and password='$mypassword'";
$result=mysql_query($sql);

$result = mysql_query($sql);
$row=mysql_fetch_array($result);
$active=$row['active'];
$count=mysql_num_rows($result);

if ($count==1){
//register $myemail, $mypassword and redirect to file
session_register("myemail");
session_register("mypassword");
header("location:welcomesuccess.php");
}
else {
echo "<p>Login failed, incorrect email or password.</p>";
}
}

?>
<form action="" method="post">
<label> Email: </label>
<input type="email" name="email"/></br>
<label> Password: </label>
<input type="password" name="password"/></br>
<input type="submit" value="Submit"/></br>
</form>