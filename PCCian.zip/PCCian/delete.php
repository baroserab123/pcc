<html>
<head>
<link rel="stylesheet" href="nw3.css">
</head>

<body>

<?php

include ("config.php");

$tbl_name="registered_members"; //TBL name
$id= $_GET['id'];

$sql="DELETE FROM $tbl_name WHERE id='$id'";
$result=mysql_query($sql);

if($result){
echo "<center>Successful";
echo "<br>";
echo "<center><a class='w3-btn  w3-hover-white' href='confirm.php' style='background-color:crimson; width:200px'>Display Records</a>";
}
else {
echo "ERROR";}



?>
<?php mysql_close();
?>



</body>

</html>